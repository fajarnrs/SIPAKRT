<x-heroicon-o-refresh {{ $attributes }} />
