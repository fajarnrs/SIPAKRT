<x-heroicon-o-stop {{ $attributes }} />
