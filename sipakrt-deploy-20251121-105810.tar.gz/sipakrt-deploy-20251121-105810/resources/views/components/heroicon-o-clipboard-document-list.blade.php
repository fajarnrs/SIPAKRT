<x-heroicon-o-clipboard-list {{ $attributes }} />
