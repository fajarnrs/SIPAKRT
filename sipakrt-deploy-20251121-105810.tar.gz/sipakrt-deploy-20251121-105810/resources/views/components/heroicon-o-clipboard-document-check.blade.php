<x-heroicon-o-clipboard-check {{ $attributes }} />
