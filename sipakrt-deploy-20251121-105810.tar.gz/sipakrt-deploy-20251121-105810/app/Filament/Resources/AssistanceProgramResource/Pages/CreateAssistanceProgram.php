<?php

namespace App\Filament\Resources\AssistanceProgramResource\Pages;

use App\Filament\Resources\AssistanceProgramResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAssistanceProgram extends CreateRecord
{
    protected static string $resource = AssistanceProgramResource::class;
}
