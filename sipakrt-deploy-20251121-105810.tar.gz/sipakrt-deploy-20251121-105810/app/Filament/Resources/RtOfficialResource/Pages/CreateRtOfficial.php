<?php

namespace App\Filament\Resources\RtOfficialResource\Pages;

use App\Filament\Resources\RtOfficialResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateRtOfficial extends CreateRecord
{
    protected static string $resource = RtOfficialResource::class;
}
